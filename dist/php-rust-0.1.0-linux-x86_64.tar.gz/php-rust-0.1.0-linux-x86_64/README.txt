php-rust Linux x86_64 runtime

Install for the current user:
  ./install.sh

Optional install location:
  ./install.sh --prefix /some/path

Run a supported PHP script:
  php-rust path/to/script.php

This package is a standalone command-line runtime and does not require PHP,
Rust, Cargo, or a web server to run. It supports only the PHP subset described
in the project README.
